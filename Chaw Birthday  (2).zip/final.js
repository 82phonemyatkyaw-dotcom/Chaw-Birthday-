const message = `ကို့ချစ်သူလေး ❤️

Happy Birthday!
ကို့ချစ်သူလေးအတွက်ကိုတတ်နိုင်သလောက်လေးပြင်ပေးထားတာပါ။ချောလေးသဘောကျမယ်လို့မျှော်လင့်မိပါတယ်။ဒီတစ်ခေါက်မွေးနေ့မှတော့ချောလေးအနားမရှိနိုင်ပေမယ့် လာမဲ့မွေးနေ့တွေမှာတော့ချောလေးအနားမှာရှိနိုင်အောင် ကြိုးစားနေပါတယ်
အများကြီးချစ်တယ် အာဘွား


❤️ Happy Birthday, ❤️
ချောရဲ့ကိုကို...`;

const text = document.getElementById("message");
const btn = document.getElementById("surpriseBtn");
const popup = document.getElementById("popup");

let i = 0;

function typeWriter() {
    if (i < message.length) {
        text.textContent += message.charAt(i);
        i++;
        setTimeout(typeWriter, 40);
    }
}

typeWriter();

btn.addEventListener("click", () => {
    popup.style.display = "flex";
});

function closePopup() {
    popup.style.display = "none";
}

function createHeart() {
    const heart = document.createElement("div");
    heart.className = "heart";
    heart.innerHTML = "❤️";

    heart.style.left = Math.random() * 100 + "vw";
    heart.style.fontSize = (20 + Math.random() * 20) + "px";
    heart.style.animationDuration = (4 + Math.random() * 3) + "s";

    document.body.appendChild(heart);

    setTimeout(() => {
        heart.remove();
    }, 7000);
}

setInterval(createHeart, 400);