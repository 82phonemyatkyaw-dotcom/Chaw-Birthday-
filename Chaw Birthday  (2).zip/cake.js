let candlesOut = 0;
let celebrationStarted = false;

// Blow out one candle
function blowOut(candle) {

    const flame = candle.querySelector(".flame");

    if (!flame || flame.style.opacity === "0") return;

    flame.style.transition = "0.5s";
    flame.style.opacity = "0";
    flame.style.transform = "scale(0)";

    // Smoke
    const smoke = document.createElement("div");
    smoke.className = "smoke";
    smoke.innerHTML = "💨";
    candle.appendChild(smoke);

    setTimeout(() => {
        smoke.remove();
    }, 1000);

    candlesOut++;

    if (candlesOut === 3 && !celebrationStarted) {
        celebrationStarted = true;
        setTimeout(showCelebration, 800);
    }
}

// Celebration
function showCelebration() {

    const message = document.getElementById("message");

    if (message) {
        message.innerHTML =
        "🎉 Happy Birthday, My Princess! ❤️<br><br>I Love You Forever 💖";
    }

    // Hearts
    const heartInterval = setInterval(createHeart, 250);

    // Fireworks
    launchFireworks();

    // Stop hearts after 5 seconds
    setTimeout(() => {
        clearInterval(heartInterval);
    }, 5000);

    // Go to final page
    setTimeout(() => {
        window.location.href = "surprise.html";
    }, 5000);

}

// Floating Hearts
function createHeart() {

    const heart = document.createElement("div");

    heart.className = "heart";
    heart.innerHTML = "❤️";

    heart.style.left = Math.random() * window.innerWidth + "px";
    heart.style.bottom = "-50px";

    heart.style.fontSize = (20 + Math.random() * 20) + "px";
    heart.style.animationDuration = (4 + Math.random() * 2) + "s";

    document.body.appendChild(heart);

    setTimeout(() => {
        heart.remove();
    }, 6000);

}

// Launch several fireworks
function launchFireworks() {

    explode(window.innerWidth / 2, 180);

    setTimeout(() => {
        explode(120, 220);
    }, 300);

    setTimeout(() => {
        explode(window.innerWidth - 120, 220);
    }, 600);

    setTimeout(() => {
        explode(window.innerWidth / 2, 350);
    }, 900);

}

// One firework explosion
function explode(x, y) {

    for (let i = 0; i < 30; i++) {

        const fire = document.createElement("div");

        fire.className = "firework";

        fire.style.left = x + "px";
        fire.style.top = y + "px";

        fire.style.backgroundColor =
            `hsl(${Math.random() * 360},100%,60%)`;

        document.body.appendChild(fire);

        const angle = Math.random() * Math.PI * 2;
        const distance = 80 + Math.random() * 120;

        fire.animate([
            {
                transform: "translate(0,0) scale(1)",
                opacity: 1
            },
            {
                transform:
                    `translate(${Math.cos(angle) * distance}px, ${Math.sin(angle) * distance}px) scale(0)`,
                opacity: 0
            }
        ], {
            duration: 1200,
            easing: "ease-out"
        });

        setTimeout(() => {
            fire.remove();
        }, 1200);

    }

}