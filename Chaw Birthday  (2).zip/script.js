
const envelope = document.getElementById("envelope");
const typing = document.getElementById("typing");
const continueBtn = document.getElementById("continueBtn");

const message =
`Before your birthday surprise begins...

ကို့ချစ်သူလေးမွေးနေ့ အတွက်ကို့တတ်နိုင်သလောက်လေးပြင်ပေးထားတာပါအများကြီးချစ်တယ် အာဘွား

Happy Birthday, ❤️`;

let index = 0;
let opened = false;

envelope.addEventListener("click", function () {

    if (opened) return;

    opened = true;

    envelope.classList.add("open");

    setTimeout(typeWriter, 900);

});

function typeWriter() {

    if (index < message.length) {

        typing.textContent += message.charAt(index);
        index++;

        setTimeout(typeWriter, 35);

    } else {

        continueBtn.style.display = "inline-block";
        console.log("Typing finished!");

    }

}

continueBtn.addEventListener("click", function (e) {

    e.stopPropagation();

    window.location.href = "gallery.html";

});